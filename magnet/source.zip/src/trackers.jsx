//function to fetch trackers
const trackers = [];
fetch("https://newtrackon.com/api/stable")
  .then((response) => response.text())
  .then((data) => {
    var chars = data.split("\n\n");
    for (let i = 0; i <= 14; i++) {
      trackers.push(chars[i]);
    }
  })
  .catch(function () {
    console.log("Error in fetching trackers.");
  });

export default trackers;
