import { observer } from "mobx-react-lite";
import React, { useEffect } from "react";
import initSqlJs from "sql.js";
const JSZip = require("jszip");
var http = require("http");
var url = require("url");

const Database = observer(({ appStore }) => {
  if (appStore.database.length === 0) {
    initSqlJs()
      .then(async (SQL) => {
        var req = http.get(url.parse("database.zip"), function (res) {
          if (res.statusCode !== 200) {
            console.log(res.statusCode);
            // handle error
            return;
          }
          var data = [];

          res.on("data", function (chunk) {
            data.push(chunk);
          });

          res.on("end", function () {
            var buf = Buffer.concat(data);

            JSZip.loadAsync(buf)
              .then(function (zip) {
                return zip.file("database.db").async("Uint8Array");
              })
              .then(function (data) {
                appStore.setDatabase(
                  new SQL.Database(new Uint8Array(data)).run(`ALTER TABLE test
          ADD stripped_name TEXT;SELECT * FROM test;
          UPDATE test SET stripped_name = replace(replace(replace(replace(name," ",""),".",""),"_",""),"-","");`)
                );
              });
          });
        });
        req.on("error", function (err) {
          // handle error
        });
      })
      .catch((err) => console.log(err));
  }
  //Algorith to search database

  useEffect(() => {
    let filteredResults = [];

    function updateResults() {
      if (appStore.value.length >= 3) {
        let searchTerm = appStore.value
          .replace(/\s/g, "")
          .replace(".", "")
          .replace("-", "")
          .replace("_", "");
        try {
          let results = null;
          let sql = `SELECT * FROM test  WHERE stripped_name LIKE '%${searchTerm}%'`;
          // The sql is executed synchronously on the UI thread.
          // You may want to use a web worker
          results = appStore.database.exec(sql); // an array of objects is returned
          results.map(({ columns, values }) => {
            values.map((value) => {
              let newObj = {};
              value.map((data, dataIndex) => {
                newObj[columns[dataIndex]] = value[dataIndex];
                return null;
              });
              filteredResults.push(newObj);
              return null;
            });
            return null;
          });
          appStore.setSearchResults(filteredResults);
        } catch (e) {}
        appStore.setSearchResults(filteredResults);
      }
    }
    updateResults();
  }, [appStore.value, appStore]);

  var styles = {
    display: "none",
  };

  return <p style={styles}>{appStore.value}</p>;
});

export default Database;
