<?PHP

try {
	
	$query = $_GET["query"];
	$query_prefix = "https://duckduckgo.com/ac/?q=";
	$query_scaped = urlencode($query);

	$queryUrl = $query_prefix.$query_scaped;

	$resultsArray = file_get_contents($queryUrl);

	$res_A = array('results' => empty($resultsArray) ? [] : json_decode($resultsArray), 'query' => $query);

	header('Content-Type: application/json');
	print json_encode($res_A);
}catch(Exception $e){
	header('Content-Type: application/json');
	$res_A = array('results' => ['ERROR'], 'query' => $query);
}


?>