<?php

// Settings
$txt['extimageproxy_enabled'] 		= 'Enable the ExtImageProxy Addon';
$txt['extimageproxy_enabled_desc'] 	= 'This addon allows you to get rid of insecure content warnings or disappearing images when you use an encrypted connection to your ElkArte Forum.';
$txt['extimageproxy_title'] 		= 'ExtImageProxy';
$txt['extimageproxy_settings'] 		= 'ExtImageProxy Settings';
$txt['extimageproxy_desc'] 		= 'This addon adds the option to use a external proxy.';

$txt['extimageproxy_options'] 		= 'ExtImageProxy Options';
$txt['extimageproxy_type'] 		= 'Image Proxy Type';
$txt['extimageproxy_camo'] 		= 'camo';
$txt['extimageproxy_nginx'] 		= 'nginx';
$txt['extimageproxy_weserv'] 		= 'weserv';
$txt['extimageproxy_custom_url'] 	= 'Custom Url';
$txt['extimageproxy_custom_key'] 	= 'Custom Key';
