# Elkarte Image Proxy

This addon allows you to get rid of insecure content warnings or disappearing images when you use an encrypted connection to your ElkArte Forum.

## Proxy Settings

By default this extension will use the [images.weserv.nl](https://images.weserv.nl) image caching and resizing proxy.
