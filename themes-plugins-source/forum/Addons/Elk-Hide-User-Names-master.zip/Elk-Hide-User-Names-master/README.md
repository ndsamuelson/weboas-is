## Hide Usernames from Guests

### Summary:
This mod will hide registered users display names from guests, keeping their identity safe from name collecting bots.  Works without making any theme edits so should work with most themes and addons.

Adds a text box in the admin panel where you can enter the name to use as the replacement, e.g. Hidden, Guest, Blocked as examples.