[center][size=14pt][b]Hide Usernames from Guests[/b][/size][/center]
[hr]

[color=blue][b][size=12pt][u]License[/u][/size][/b][/color]
This modification is released under a MPL V1.1 license, a copy of it with its provisions is included with the package.

[color=blue][b][size=12pt][u]Introduction[/u][/size][/b][/color]
This mod will hide registered users display names from guests, keeping their identity safe from name collecting bots

[color=blue][b][size=12pt][u]Features[/u][/size][/b][/color]
o Works without making any theme edits so should work with most themes and addons.
o Adds a text box in the admin panel where you can enter the name to use as the replacement, e.g. Hidden, Guest, Blocked as examples.