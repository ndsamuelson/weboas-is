<?php
$helptxt['hideusernames'] = 'Enter the default user display name that guests will see, e.g. Hidden or Guest, all areas where users names would normally appear will be changed to this to provide increase user anonymity from guests';
$txt['hideusernames'] = 'User name for Guests to see<br /><span class="smalltext">e.g. Hidden</span>';