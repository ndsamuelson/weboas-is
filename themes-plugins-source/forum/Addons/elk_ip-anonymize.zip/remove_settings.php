<?php

/**
 * @name      IP Anonymize
 * @copyright Maria Mata
 * @license   MPL 1.1 http://mozilla.org/MPL/1.1/
 *
 * @version 1.0.0
 *
 */

// If we have found SSI.php and we are outside of ELK, then we are running standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('ELK'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('ELK')) // If we are outside ELK and can't find SSI.php, then throw an error
	die('<b>Error:</b> Cannot install - please verify you put this file in the same place as Elkarte\'s SSI.php.');

global $modSettings;

$db = database();
$dbtbl = db_table();

// List all mod settings here to REMOVE
$mod_settings_to_remove = array(
	'ipanonymize_custom_ip',
);

// REMOVE rows from an existing table
$db->query('', '
	DELETE FROM {db_prefix}scheduled_tasks
	WHERE task = {string:name}',
	array(
		'name' => 'scheduled_ipanonymize',
	)
);

if (count($mod_settings_to_remove) > 0) {

	foreach ($mod_settings_to_remove as $setting)
		if (isset($modSettings[$setting]))
			unset($modSettings[$setting]);

	$db->query('', '
		DELETE FROM {db_prefix}settings
		WHERE variable IN ({array_string:settings})',
		array(
			'settings' => $mod_settings_to_remove,
		)
	);

	updateSettings(array(
		'settings_updated' => time(),
	));
}

if (ELK == 'SSI')
   echo 'Congratulations! You have successfully removed the integration hooks.';