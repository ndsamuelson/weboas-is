## IP Anonymize

### Introduction
This add-on adds the ability to replace the IP addresses of all users with a custom IP address, in order to help protect their privacy.

### License
The software is licensed under [Mozilla Public License 1.1 (MPL-1.1)](http://opensource.org/licenses/MPL-1.1).

### Features
* Ability to replace all IP addresses belonging to users in a batch job.
* Ability to define a custom IP address (Admin -> Configuration -> Add-on Settings -> IP Anonymize).
* Can run as a scheduled task or on demand (Admin -> Maintenance -> Scheduled Tasks -> Scheduled Tasks).

### Installation
Simply upload and install the package to install this add-on on ElkArte.