<?php

/**
 * @name      IP Anonymize
 * @copyright Maria Mata
 * @license   MPL 1.1 http://mozilla.org/MPL/1.1/
 *
 * @version 1.0.0
 *
 */

// If we have found SSI.php and we are outside of ELK, then we are running standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('ELK'))
{
	require_once(dirname(__FILE__) . '/SSI.php');
}
elseif (!defined('ELK')) // If we are outside ELK and can't find SSI.php, then throw an error
{
	die('<b>Error:</b> Cannot install - please verify you put this file in the same place as Elkarte\'s SSI.php.');
}

$db = database();
$dbtbl = db_table();

// Settings to create the new tables...
$tables = array();

// Add a row to an existing table
$rows = array();
$rows[] = array(
	'method' => 'ignore',
	'table_name' => '{db_prefix}scheduled_tasks',
	'columns' => array(
		'next_time' => 'int',
		'time_offset' => 'int',
		'time_regularity' => 'int',
		'time_unit' => 'string',
		'disabled' => 'int',
		'task' => 'string',
	),
	'data' => array(1231542000, 39620, 1, 'd', 1, 'scheduled_ipanonymize'),
	'keys' => array('id_task'),
);

foreach ($tables as $table)
{
	$dbtbl->db_create_table($table['table_name'], $table['columns'], $table['indexes'], $table['parameters'], $table['if_exists'], $table['error']);
}

foreach ($rows as $row)
{
	$db->insert($row['method'], $row['table_name'], $row['columns'], $row['data'], $row['keys']);
}

if (ELK === 'SSI')
{
	echo 'Congratulations! You have successfully installed this addon!';
}