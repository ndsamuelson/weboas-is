[hr]
[center][size=16pt][b]IP Anonymize[/b][/size]
[/center]
[hr]

[color=blue][b][size=12pt][u]Introduction[/u][/size][/b][/color]
This add-on adds the ability to replace the IP addresses of all users with a custom IP address, in order to help protect their privacy.

[color=blue][b][size=12pt][u]License[/u][/size][/b][/color]
This modification is released under a MPL V1.1 license, a copy of it with its provisions is included with the package.

[color=blue][b][size=12pt][u]Features[/u][/size][/b][/color]
[list]
[li]Ability to replace all IP addresses belonging to users in a batch job.[/li]
[li]Ability to define a custom IP address (Admin -> Configuration -> Add-on Settings -> IP Anonymize).[/li]
[li]Can run as a scheduled task or on demand (Admin -> Maintenance -> Scheduled Tasks -> Scheduled Tasks).[/li]
[/list]

[color=blue][b][size=12pt][u]Installation[/u][/size][/b][/color]
Simply upload and install the package to install this add-on on ElkArte.