<?php

/**
 * @package "IP Anonymize" Addon for ElkArte
 * @author Maria Mata
 * @copyright (c) 2020 Maria Mata
 * @license Mozilla Public License version 1.1 http://www.mozilla.org/MPL/1.1/.
 *
 * @version 1.0.0
 *
 */

if (!defined('ELK'))
{
	die('No access...');
}

/* Admin Hook, integrate_admin_areas, called from Admin.php
   Used to add/modify admin menu areas */
function admin_areas_ipanonymize(&$admin_areas)
{
	global $txt;
	loadLanguage('ipanonymize');
	$admin_areas['config']['areas']['addonsettings']['subsections']['ipanonymize'] = array($txt['ipanonymize_title']);
}

/* Admin Hook, integrate_sa_modify_modifications, called from AddonSettings.controller.php
   Used to add subactions to the addon area */
function admin_ipanonymize(&$sub_actions)
{
	global $context, $txt;
	$sub_actions['ipanonymize'] = array(
		'dir' => SUBSDIR,
		'file' => 'ipanonymize.subs.php',
		'function' => 'settings_ipanonymize',
		'permission' => 'admin_forum',
	);
	$context[$context['admin_menu_name']]['tab_data']['tabs']['ipanonymize']['description'] = $txt['ipanonymize_desc'];
}

/* Defines our settings array and uses our settings class to manage the data */
function settings_ipanonymize()
{
	global $txt, $context, $scripturl, $modSettings;
	loadLanguage('ipanonymize');
	require_once(SUBSDIR . '/SettingsForm.class.php');
	$ipAnonymizeSettings = new Settings_Form();

    $config_vars = array (
        array('title', 'ipanonymize_options'),
		array('text', 'ipanonymize_custom_ip'),
	);
	if (!isset($modSettings['ipanonymize_custom_ip']))
		$modSettings['ipanonymize_custom_ip'] = '127.0.0.1'; // Default IP

	$ipAnonymizeSettings->settings($config_vars);

	if (isset($_GET['save']))
	{
		checkSession();
		Settings_Form::save_db($config_vars);
		redirectexit('action=admin;area=addonsettings;sa=ipanonymize');
	}

	$context['settings_title'] = $txt['ipanonymize_title'];
	$context['page_title'] = $context['settings_title'] = $txt['settings_ipanonymize'];
	$context['post_url'] = $scripturl . '?action=admin;area=addonsettings;sa=ipanonymize;save';
	Settings_Form::prepare_db($config_vars);
}

/* Integration hook, integrate_list_scheduled_tasks, called from ManageScheduledTasks.controller */
function ilst_ipanonymize(&$listOptions)
{	
	loadLanguage('ipanonymize'); // Just need our language strings for the listing
}

/* Called from the scheduled task area, runs ipanonymize on a reoccurring basis (integrate_autotask_include) */
function scheduled_ipanonymize()
{
	global $modSettings;

	loadEssentialThemeData();
	loadLanguage('Admin');
	loadLanguage('ipanonymize');

	ipanonymize_updateIPs();

	return true;
}

function ipanonymize_updateIPs()
{

	$db = database();
	global $modSettings;

	$custom_ip = $modSettings['ipanonymize_custom_ip'];

	$db->query('', "
		UPDATE {db_prefix}log_errors
		SET ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}log_actions
		SET ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}log_badbehavior
		SET ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}log_banned
		SET ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}log_floodcontrol
		SET ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}log_online
		SET ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}member_logins
		SET ip='$custom_ip', ip2='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}log_agreement_accept
		SET accepted_ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}log_privacy_policy_accept
		SET accepted_ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}log_reported_comments
		SET member_ip='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}members
		SET member_ip='$custom_ip', member_ip2='$custom_ip'"
	);

	$db->query('', "
		UPDATE {db_prefix}messages
		SET poster_ip='$custom_ip'"
	);

}
