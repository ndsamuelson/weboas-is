<?php

$txt['ipanonymize'] = 'IP Anonymize';
$txt['ipanonymizeed'] = 'Anonymized!';
$txt['scheduled_task_desc_scheduled_ipanonymize'] = 'Replaces all IP addresses of users in the database.';
$txt['scheduled_task_scheduled_ipanonymize'] = 'IP Anonymize';
$txt['ipanonymize_decode_error'] = 'Json Decode Error';
$txt['ipanonymize_title'] = 'IP Anonymize';
$txt['ipanonymize_settings'] = 'IP Anonymize Settings';
$txt['ipanonymize_desc'] = 'This add-on allows you to replace all IP addresses belonging to users in the database with a custom IP address. To run it, go to Admin -> Maintenance -> Scheduled Tasks -> Scheduled Tasks.';
$txt['ipanonymize_custom_ip'] = 'IP address<br><div class="smalltext">This will be used to replace the IP addresses of users in the database</div>';
$txt['ipanonymize_options'] = 'Settings';
