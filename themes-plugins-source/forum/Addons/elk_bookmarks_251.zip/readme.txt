[center][size=16pt][b]Bookmarks for ElkArte[/b][/size][/center]
[hr]

[color=blue][b][size=12pt][u]License[/u][/size][/b][/color]
This Elkarte addon is released under a BSD-3-Clause license.

[color=blue][b][size=12pt][u]Introduction[/u][/size][/b][/color]
With this simple addon you can easily keep track of the topics that you like as bookmarks.  Each user will have their own bookmark list enabling them to easily find the topics that they refer to often.

[color=blue][b][size=12pt][u]Features[/u][/size][/b][/color]
 o One-click adding of bookmarks.
 o User friendly interface for managing bookmarks.
 o Automatically delete bookmarks when the topic they link to is deleted.
 o No source edit, all done with hooks.

[color=blue][b][size=12pt][u]Repo[/u][/size][/b][/color]
https://bitbucket.org/spuds_/elk_bookmarks
[color=blue][b][size=12pt][u]Source[/u][/size][/b][/color]
https://bitbucket.org/spuds_/elk_bookmarks/src
[color=blue][b][size=12pt][u]Download[/u][/size][/b][/color]
https://bitbucket.org/spuds_/elk_bookmarks/downloads