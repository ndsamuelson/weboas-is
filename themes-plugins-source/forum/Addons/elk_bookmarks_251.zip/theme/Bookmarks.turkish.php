<?php

$txt['bookmarks_enabled'] = 'Favori Konuları aç';
$txt['bookmarks'] = 'Favori Konularım';
$txt['bookmark_list'] = 'Favori Konular';
$txt['bookmark'] = 'Favoriler';
$txt['bookmark_list_empty'] = 'Şuan Hiç Favori Konunuz Yok!. Mesajdaki \'Favorilerime ekle\' butonunu kullanarak ekleyebilirsiniz.';
$txt['bookmark_open_window'] = 'Yeni Pencerede Aç';
$txt['bookmark_delete'] = 'Seçilen Favori Konuyu Sil';
$txt['bookmark_delete_success'] = '%1$s Favori Konu Silindi!';
$txt['bookmark_delete_failure'] = 'Favori Konu Silinemedi.';
$txt['bookmark_add'] = 'Favorilerime Ekle';
$txt['bookmark_delete'] = 'Favori Konuyu Sil';
$txt['bookmark_add_success'] = 'Konu, Favori Konularınıza eklendi!';
$txt['bookmark_add_exists'] = 'Bu Konu Zaten Favori Konularınızda Var!';
$txt['bookmark_add_failed'] = 'Favori Konu Eklemede Hata!';
$txt['permissionname_make_bookmarks'] = 'Favoriler icin konu oluşturabilir';
$txt['cannot_make_bookmarks'] = 'Maalesef, Favori konu oluşturma izniniz yok.';
