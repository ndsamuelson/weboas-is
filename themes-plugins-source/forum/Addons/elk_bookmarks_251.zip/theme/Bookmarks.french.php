<?php

$txt['bookmarks_enabled'] = 'Activer les favoris';
$txt['bookmarks'] = 'Mes favoris';
$txt['bookmark_list'] = 'Favoris';
$txt['bookmark'] = 'Favori';
$txt['bookmark_list_empty'] = 'Vous avez aucun favori pour le moment. Ajoutez-en un en cliquant sur \'Ajouter favori\' dans les sujets.';
$txt['bookmark_open_window'] = 'Ouvrir dans une nouvelle fenêtre';
$txt['bookmark_delete'] = 'Supprimer les favoris sélectionnés';
$txt['bookmark_delete_success'] = '%1$s favoris ont été supprimés avec succès !';
$txt['bookmark_delete_failure'] = 'Aucun favori n\'a été supprimé.';
$txt['bookmark_add'] = 'Ajouter favori';
$txt['bookmark_delete'] = 'Supprimer favori';
$txt['bookmark_add_success'] = 'Ce sujet a été ajouté à vos favoris avec succèc !';
$txt['bookmark_add_exists'] = 'Ce sujet est déjà dans vos favoris !';
$txt['bookmark_add_failed'] = 'Echec lors de l\'ajout de ce sujet à vos favoris.';
$txt['permissionname_make_bookmarks'] = 'Créer des favoris pour les sujets';
$txt['cannot_make_bookmarks'] = 'Désolé, vous n\'avez pas le droit de créer des favoris.';
?>