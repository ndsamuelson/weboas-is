<?php

$txt['bookmarks_enabled'] = 'Abilita Segnalibri';
$txt['bookmarks'] = 'I miei Segnalibri';
$txt['bookmark_list'] = 'Segnalibri';
$txt['bookmark'] = 'Segnalibro';
$txt['bookmark_list_empty'] = 'Al momento non hai segnalibri. Puoi aggiungere nuovi segnalibri cliccando su \'aggiungi segnalibro\' all\'interno dei topic.';
$txt['bookmark_open_window'] = 'Apri in una nuova finestra';
$txt['bookmark_delete'] = 'Elimina segnalibri selezionati';
$txt['bookmark_delete_success'] = '%1$s segnalibri eliminati con successo!';
$txt['bookmark_delete_failure'] = 'Nessun segnalibro è stato cancellato.';
$txt['bookmark_add'] = 'Aggiungi segnalibro';
$txt['bookmark_delete'] = 'Rimuovi segnalibro';
$txt['bookmark_add_success'] = 'Il topic è stato aggiunto con successo ai tuoi segnalibri!';
$txt['bookmark_add_exists'] = 'Questo topic è già presente nei tuoi segnalibri!';
$txt['bookmark_add_failed'] = 'Impossibile aggiungere il topic ai tuoi segnalibri.';
$txt['permissionname_make_bookmarks'] = 'Crea segnalibri per topic';
$txt['cannot_make_bookmarks'] = 'Spiacenti, non hai i permessi necessari per creare segnalibri.';
