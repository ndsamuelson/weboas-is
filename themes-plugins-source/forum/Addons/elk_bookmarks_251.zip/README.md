## Bookmarks for ElkArte

## License
This Elkarte addon is released under a [BSD-3-Clause](http://opensource.org/licenses/BSD-3-Clause) license.

## Introduction
With this simple addon you can easily keep track of the topics that you like as bookmarks.  Each user will have their own bookmark list enabling them to find the topics that they refer to often.

## Features
  - One-click adding of bookmarks.
  - User friendly interface for managing bookmarks.
  - Automatically delete bookmarks when the topic they link to is deleted.
  - No source edit, all done with hooks.