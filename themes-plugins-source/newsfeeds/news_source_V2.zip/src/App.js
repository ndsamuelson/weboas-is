import React from "react";
import { Route } from "react-router-dom";
import SettingsPage from "./SettingsPage";
import "./App.css";
import TopBar from "./TopBar";
import TopFeeds from "./TopFeeds";

function App({ feedsStore }) {
  return (
    <div className="App">
      <TopBar />
      <Route
        path="/"
        exact
        component={(props) => <TopFeeds {...props} feedsStore={feedsStore} />}
      />
      <Route
        path="/settings"
        exact
        component={(props) => (
          <SettingsPage {...props} feedsStore={feedsStore} />
        )}
      />
    </div>
  );
}

export default App;
