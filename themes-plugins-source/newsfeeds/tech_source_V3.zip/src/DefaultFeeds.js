const defaultFeeds = [
  { name: "Null Byte", url: "https://null-byte.wonderhowto.com/rss.xml" },
  { name: "HackerNews", url: "https://feeds.feedburner.com/TheHackersNews" },
  { name: "ESET", url: "http://feeds.feedburner.com/eset/blog/" },
  { name: "Phoronix", url: "https://www.phoronix.com/rss.php" },
  { name: "AnandTech", url: "https://www.anandtech.com/rss/" },
  { name: "wccftech", url: "https://wccftech.com/feed/" },
  {
    name: "Tech Worm",
    url: "https://www.techworm.net/feed",
  },
  {
    name: "KrebSon",
    url: "	'https://krebsonsecurity.com/feed/'",
  },
  {
    name: "Washington Examiner",
    url: "https://www.washingtonexaminer.com/tag/technology.rss",
  },
  { name: "The Wire Cutter", url: "https://thewirecutter.com/feed/" },
  {
    name: "The Inquirer",
    url: "https://www.theinquirer.net/feeds/rss",
  },
  { name: "RiskyBiz", url: "https://risky.biz/rss.xml" },
  { name: "CX Security", url: "https://cxsecurity.com/wlb/rss/exploit/" },
  { name: "Seclists", url: "http://seclists.org/rss/fulldisclosure.rss" },
  {
    name: "Security Weekly",
    url: "http://feeds.feedburner.com/securityweekly/",
  },
  { name: "Deep Dot Web", url: "https://www.deepdotweb.com/feed/" },
  {
    name: "Macrumors",
    url: "http://feeds.macrumors.com/MacRumors-All",
  },
  {
    name: "9to5Mac",
    url: "https://9to5mac.com/feed/",
  },
  { name: "neowin-main", url: "https://feeds.feedburner.com/neowin-main" },
  { name: "Securelist", url: "https://securelist.com/feed/" },
  { name: "XDA", url: "https://www.xda-developers.com/feed/" },
  {
    name: "Eff",
    url: "https://www.eff.org/rss/updates.xml",
  },
  { name: "ONMSFT", url: "https://www.onmsft.com/feed" },
  {
    name: "Fossbytes",
    url: "https://fossbytes.com/feed/",
  },
  {
    name: "Bleeping Computer",
    url: "https://www.bleepingcomputer.com/feed/",
  },
  { name: "Ghacks", url: "https://www.ghacks.net/feed/" },
  { name: "Naked Security", url: "https://nakedsecurity.sophos.com/feed/" },
  { name: "ZD Net", url: "http://www.zdnet.com/blog/security/rss.xml" },
  { name: "Security Affairs", url: "http://securityaffairs.co/wordpress/feed" },
  { name: "Dark Reading", url: "https://www.darkreading.com/rss_simple.asp" },
  {
    name: "Extreme Tech",
    url: "https://www.extremetech.com/computing/feed",
  },
  { name: "TWIT", url: "http://feeds.twit.tv/brickhouse_video_hd.xml" },
  {
    name: "Welivesecurity",
    url: "https://www.welivesecurity.com/feed/",
  },
  {
    name: "Tech Republic",
    url: "https://www.techrepublic.com/rssfeeds/articles/",
  },
  { name: "Tech Crunch", url: "http://feeds.feedburner.com/TechCrunch/" },
  {
    name: "Computer World",
    url: "http://www.computerworld.com/news/index.rss",
  },
  { name: "ExtremeTech", url: "https://www.extremetech.com/feed" },
  { name: "Tech Radar", url: "http://www.techradar.com/rss" },
  { name: "Read Write", url: "https://readwrite.com/feed/" },
  {
    name: "Guardian, Technology",
    url: "https://www.theguardian.com/us/technology/rss",
  },
  {
    name: "Linux Insider",
    url: "https://www.linuxinsider.com/perl/syndication/rssfull.pl",
  },
  {
    name: "LXER",
    url: "http://lxer.com/module/newswire/headlines.rss",
  },
  { name: "Coin Desk", url: "https://feeds.feedburner.com/CoinDesk" },
  {
    name: "Coin Telegraph",
    url: "https://cointelegraph.com/rss",
  },
  {
    name: "The Verge",
    url: "https://www.theverge.com/rss/index.xml",
  },
  { name: "The Register", url: "https://www.theregister.co.uk/headlines.atom" },
  {
    name: "Threat Post",
    url: "https://threatpost.com/feed/",
  },
  {
    name: "ARS Technica",
    url: "http://feeds.arstechnica.com/arstechnica/index/",
  },
  {
    name: "Reuters Technology",
    url: "http://feeds.reuters.com/reuters/technologyNews",
  },
  { name: "Guru 3D", url: "https://www.guru3d.com/news_rss" },
  {
    name: "Slash Dot",
    url: "http://rss.slashdot.org/Slashdot/slashdotMain",
  },
  {
    name: "Torrent Freak",
    url: "https://feeds.feedburner.com/Torrentfreak",
  },
];

export default defaultFeeds;
