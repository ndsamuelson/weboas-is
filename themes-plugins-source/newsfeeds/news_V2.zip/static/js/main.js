(window["webpackJsonpreact-rss-tutorial-app"] =
  window["webpackJsonpreact-rss-tutorial-app"] || []).push([
  [0],
  {
    222: function (e, t, a) {
      e.exports = a(481);
    },
    227: function (e, t, a) {},
    229: function (e, t, a) {},
    376: function (e, t, a) {},
    398: function (e, t, a) {},
    417: function (e, t) {},
    419: function (e, t) {},
    452: function (e, t) {},
    454: function (e, t) {},
    481: function (e, t, a) {
      "use strict";
      a.r(t);
      var n = a(0),
        r = a.n(n),
        s = a(39),
        l = a.n(s),
        c = a(489),
        o = a(26),
        i = a(220),
        m = a.n(i),
        u = (a(227), a(32)),
        d = a(33),
        w = a.n(d),
        p = a(56),
        f = a(51),
        h = (a(229), a(78)),
        b = a(21),
        g = a.n(b),
        v = a(221),
        E = a(28),
        y = a.n(E),
        S = a(77),
        x = a.n(S),
        N = a(50),
        k = a.n(N),
        O = a(80),
        //Change default urls here
        j = [
          { name: "BBC News", url: "http://feeds.bbci.co.uk/news/rss.xml" },
          {
            name: "The Intercept",
            url: "https://theintercept.com/feed/?lang=en",
          },
          {
            name: "Al Jazeera",
            url: "http://www.aljazeera.com/xml/rss/all.xml",
          },
          { name: "UPI News", url: "http://rss.upi.com/news/top_news.rss" },
          { name: "Newsday", url: "http://www.newsday.com/cmlink/1.1284874" },
          { name: "The IB Times", url: "http://www.ibtimes.com/rss" },
          {
            name: "NY Times",
            url: "http://rss.nytimes.com/services/xml/rss/nyt/World.xml",
          },
          {
            name: "Fox News",
            url: "http://feeds.foxnews.com/foxnews/politics?format=xml",
          },
          {
            name: "Reuters",
            url: "http://feeds.reuters.com/reuters/topNews?format=xml",
          },
          {
            name: "ABC News",
            url: "https://abcnews.go.com/abcnews/topstories",
          },
          {
            name: "Zero Hedge",
            url: "http://feeds.feedburner.com/zerohedge/feed?format=xml",
          },
          { name: "NPR", url: "http://www.npr.org/rss/rss.php?id=1001" },
          { name: "TMZ", url: "http://www.tmz.com/category/politix/rss.xml" },
          { name: "NY POST", url: "http://nypost.com/news/feed/" },
          {
            name: "The Guardian World",
            url: "https://www.theguardian.com/world/rss",
          },
          {
            name: "The Guardian US",
            url: "https://www.theguardian.com/us-news/rss",
          },
          {
            name: "Daily Mail US",
            url: "https://www.dailymail.co.uk/ushome/index.rss",
          },
          {
            name: "Daily Mail World",
            url: "https://www.dailymail.co.uk/news/worldnews/index.rss",
          },
          {
            name: "The Sun",
            url: "https://www.thesun.co.uk/news/worldnews/feed/",
          },
          { name: "The Hill", url: "https://thehill.com/rss/syndicator/19109" },
          {
            name: "PBS",
            url: "https://www.pbs.org/newshour/feeds/rss/headlines",
          },
          {
            name: "Washington Examiner",
            url: "https://www.washingtonexaminer.com/tag/news.rss",
          },
          { name: "CBS News", url: "https://www.cbsnews.com/latest/rss/main" },
          {
            name: "Politico",
            url: "https://www.politico.com/rss/politicopicks.xml",
          },
          {
            name: "CNBC",
            url: "https://www.cnbc.com/id/100727362/device/rss/rss.html",
          },
          { name: "LA Times", url: "https://www.latimes.com/world-nation.rss" },
          {
            name: "Independent",
            url: "http://www.independent.co.uk/news/world/rss",
          },
          { name: "News Week", url: "http://www.newsweek.com/rss" },
          {
            name: "NBC News",
            url: "http://feeds.nbcnews.com/nbcnews/public/news",
          },
          { name: "SCMP", url: "https://www.scmp.com/rss/91/feed" },
          {
            name: "Sky News",
            url: "http://feeds.skynews.com/feeds/rss/world.xml",
          },
          { name: "CBC", url: "https://www.cbc.ca/cmlink/rss-world" },
          {
            name: "Global News",
            url: "https://globalnews.ca/category/world/feed/",
          },
          {
            name: "Chicago Tribune",
            url:
              "https://www.chicagotribune.com/arcio/rss/category/nation-world",
          },
          { name: "Daily Caller", url: "http://dailycaller.com/feed/" },
          { name: "Reason", url: "https://reason.com/feed/" },
        ],
        C = a(169),
        T = O.object({
          name: O.string().required("URL is required"),
          url: O.string()
            .required("URL is required")
            .matches(
              /(https?:\/\/)?([\w\-])+\.{1}([a-zA-Z]{2,63})([\/\w-]*)*\/?\??([^#\n\r]*)?#?([^\n\r]*)/,
              "Invalid URL"
            ),
        });
      var B = Object(h.a)(function (e) {
          var t = this,
            a = e.feedsStore,
            s = Object(n.useState)(!1),
            l = Object(f.a)(s, 2),
            c = l[0],
            o = l[1],
            i = Object(n.useState)(!1),
            m = Object(f.a)(i, 2),
            d = m[0],
            h =
              (m[1],
              (function () {
                var e = Object(p.a)(
                  w.a.mark(function e(t, n) {
                    var r, s, l;
                    return w.a.wrap(
                      function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return (
                                (r = n.setSubmitting),
                                (s = n.setErrors),
                                (l = n.resetForm),
                                (e.prev = 1),
                                (e.next = 4),
                                T.validate(t)
                              );
                            case 4:
                              l({}),
                                a.feeds.push(t),
                                a.setFeeds(a.feeds),
                                localStorage.setItem(
                                  "newsfeeds",
                                  JSON.stringify(a.feeds)
                                ),
                                (e.next = 14);
                              break;
                            case 10:
                              (e.prev = 10),
                                (e.t0 = e.catch(1)),
                                r(!1),
                                s({ submit: e.t0.message });
                            case 14:
                            case "end":
                              return e.stop();
                          }
                      },
                      e,
                      null,
                      [[1, 10]]
                    );
                  })
                );
                return function (t, a) {
                  return e.apply(this, arguments);
                };
              })()),
            b = function (e) {
              a.feeds.splice(e, 1),
                a.setFeeds(a.feeds),
                localStorage.setItem("newsfeeds", JSON.stringify(a.feeds));
            };
          return (
            Object(n.useEffect)(
              function () {
                if (!c) {
                  var e = [];
                  try {
                    (e = JSON.parse(localStorage.getItem("newsfeeds"))),
                      Array.isArray(e) ? a.setFeeds(e) : a.setFeeds(j);
                  } catch (t) {}
                  o(!0), console.log("Useeffect ran");
                }
              },
              [c]
            ),
            d
              ? r.a.createElement(u.a, {
                  to: "/feed?".concat(C.encode({ url: a.feed })),
                })
              : r.a.createElement(
                  "div",
                  { className: "home-page" },
                  r.a.createElement("h1", { className: "center" }, "RSS Feeds"),
                  r.a.createElement(
                    v.a,
                    {
                      validationSchema: T,
                      onSubmit: h,
                      initialValues: { name: "", url: "" },
                    },
                    function (e) {
                      var t = e.handleSubmit,
                        a = e.handleChange,
                        n = (e.handleBlur, e.values),
                        s = e.touched,
                        l = (e.isInvalid, e.errors);
                      return r.a.createElement(
                        "div",
                        null,
                        r.a.createElement("h5", null, "Add a RSS feed"),
                        r.a.createElement(
                          y.a,
                          { noValidate: !0, onSubmit: t },
                          r.a.createElement(
                            y.a.Row,
                            null,
                            r.a.createElement(
                              y.a.Group,
                              { as: x.a, md: "12", controlId: "name" },
                              r.a.createElement(y.a.Control, {
                                type: "text",
                                name: "name",
                                placeholder: "Name",
                                value: n.name || "",
                                onChange: a,
                                isInvalid: s.name && l.name,
                              }),
                              r.a.createElement(
                                y.a.Control.Feedback,
                                { type: "invalid" },
                                l.name
                              )
                            ),
                            r.a.createElement(
                              y.a.Group,
                              { as: x.a, md: "12", controlId: "url" },
                              r.a.createElement(y.a.Control, {
                                type: "text",
                                name: "url",
                                placeholder: "URL",
                                value: n.url || "",
                                onChange: a,
                                isInvalid: s.url && l.url,
                              }),
                              r.a.createElement(
                                y.a.Control.Feedback,
                                { type: "invalid" },
                                l.url
                              )
                            )
                          ),
                          r.a.createElement(k.a, { type: "submit" }, "Add")
                        )
                      );
                    }
                  ),
                  r.a.createElement("br", null),
                  r.a.createElement(
                    k.a,
                    {
                      variant: "primary",
                      onClick: function () {
                        localStorage.removeItem("newsfeeds"), o(!1);
                      },
                    },
                    "Reset All"
                  ),
                  r.a.createElement("br", null),
                  r.a.createElement("br", null),
                  a.feeds.map(function (e, a) {
                    return r.a.createElement(
                      g.a,
                      { key: a },
                      r.a.createElement(
                        g.a.Title,
                        { className: "card-title" },
                        e.name
                      ),
                      r.a.createElement(
                        g.a.Subtitle,
                        { style: { paddingLeft: "20px" } },
                        e.url
                      ),
                      r.a.createElement(
                        g.a.Body,
                        null,
                        r.a.createElement(
                          k.a,
                          { variant: "primary", onClick: b.bind(t, a) },
                          "Delete"
                        )
                      )
                    );
                  })
                )
          );
        }),
        I = (a(376), a(216)),
        F = a(59),
        D = a.n(F),
        A = a(127),
        R = a.n(A);
      var L = Object(u.f)(function (e) {
          return (
            Object(I.a)(e),
            r.a.createElement(
              D.a,
              { bg: "primary", expand: "lg", variant: "dark" },
              r.a.createElement(
                D.a.Brand,
                null,
                r.a.createElement(
                  o.b,
                  {
                    style: { color: "white", textDecoration: "none" },
                    to: "/",
                  },
                  "News"
                )
              ),
              r.a.createElement(D.a.Toggle, {
                "aria-controls": "basic-navbar-nav",
              }),
              r.a.createElement(
                D.a.Collapse,
                { id: "basic-navbar-nav" },
                r.a.createElement(
                  R.a,
                  { className: "mr-auto" },
                  r.a.createElement(
                    R.a.Link,
                    {
                      href: "https://weboas.is/",
                      style: { color: "white", textDecoration: "none" },
                    },
                    "Home"
                  ),
                  r.a.createElement(
                    o.b,
                    {
                      style: { color: "white", textDecoration: "none" },
                      className: "nav-item nav-link active",
                      to: "/settings",
                    },
                    "Settings"
                  )
                )
              )
            )
          );
        }),
        U = a(490),
        q = (a(398), a(399)),
        J = a(445),
        W = a(446),
        P = (new (a(447))(), a(470));
      var z = Object(u.f)(
        Object(h.a)(function (e) {
          var t = this,
            a = e.feedsStore,
            s = Object(n.useState)(!1),
            l = Object(f.a)(s, 2),
            c = l[0],
            o = l[1],
            i = Object(n.useState)([]),
            m = Object(f.a)(i, 2),
            u = m[0],
            d = m[1],
            h = [],
            b = (function () {
              var e = Object(p.a)(
                w.a.mark(function e(t) {
                  return w.a.wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            q.load(
                              "https://req.prototypr.io/" + t.url,
                              function (e, a) {
                                if (e) console.log("error" + t);
                                else {
                                  a.items.map(function (e) {
                                    return (e.sourceName = a.title);
                                  });
                                  var n = P.uniqBy(a.items, "title");
                                  h.push(P.uniqBy(a.items, "title")),
                                    (n = []),
                                    d(h.flat()),
                                    console.log(n);
                                }
                              }
                            )
                          );
                        case 2:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              );
              return function (t) {
                return e.apply(this, arguments);
              };
            })();
          Object(n.useEffect)(
            function () {
              if (!c) {
                var e = [];
                try {
                  (e = JSON.parse(localStorage.getItem("newsfeeds"))),
                    Array.isArray(e) ? a.setFeeds(e) : a.setFeeds(j);
                } catch (t) {
                  console.log("error" + t);
                }
                a.feeds.map(
                  (function () {
                    var e = Object(p.a)(
                      w.a.mark(function e(t) {
                        return w.a.wrap(function (e) {
                          for (;;)
                            switch ((e.prev = e.next)) {
                              case 0:
                                return (e.next = 2), b(t);
                              case 2:
                                (h = []), console.log("I am updating");
                              case 4:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                      })
                    );
                    return function (t) {
                      return e.apply(this, arguments);
                    };
                  })()
                );
              }
              o(!0);
            },
            [c]
          );
          var v = function (e) {
            window.open(e);
          };
          return 0 === u.length
            ? r.a.createElement(
                "div",
                { className: "feed-page" },
                r.a.createElement("h2", null, " Loading! "),
                " "
              )
            : r.a.createElement(
                "div",
                { className: "feed-page" },
                " ",
                u
                  .sort(function (e, t) {
                    var a = new Date(e.pubDate).getTime();
                    return new Date(t.pubDate).getTime() - a;
                  })
                  .splice(0, 250)
                  .map(function (e, a) {
                    if (void 0 != e.pubDate)
                      return r.a.createElement(
                        g.a,
                        { key: a },
                        r.a.createElement(
                          g.a.Header,
                          { className: "card-title" },
                          " ",
                          e.title,
                          " "
                        ),
                        r.a.createElement(
                          g.a.Body,
                          null,
                          r.a.createElement(
                            g.a.Text,
                            null,
                            " ",
                            W.decode(
                              J(e.description).substring(0, 150) + "..."
                            ),
                            " "
                          ),
                          " ",
                          r.a.createElement(
                            g.a.Text,
                            { className: "time-ago" },
                            r.a.createElement(
                              "span",
                              null,
                              r.a.createElement(U.a, {
                                date: new Date(e.pubDate),
                              }),
                              " ",
                              r.a.createElement(
                                "span",
                                null,
                                " ",
                                "  from ".concat(e.sourceName),
                                " "
                              ),
                              " "
                            ),
                            " "
                          ),
                          " ",
                          " ",
                          r.a.createElement(
                            k.a,
                            { variant: "primary", onClick: v.bind(t, e.link) },
                            "Open",
                            " "
                          ),
                          " "
                        ),
                        " "
                      );
                  }),
                " "
              );
        })
      );
      var G = function (e) {
        var t = e.feedsStore;
        return r.a.createElement(
          "div",
          { className: "App" },
          r.a.createElement(L, null),
          r.a.createElement(u.b, {
            path: "/",
            exact: !0,
            component: function (e) {
              return r.a.createElement(
                z,
                Object.assign({}, e, { feedsStore: t })
              );
            },
          }),
          r.a.createElement(u.b, {
            path: "/settings",
            exact: !0,
            component: function (e) {
              return r.a.createElement(
                B,
                Object.assign({}, e, { feedsStore: t })
              );
            },
          })
        );
      };
      Boolean(
        "localhost" === window.location.hostname ||
          "[::1]" === window.location.hostname ||
          window.location.hostname.match(
            /^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/
          )
      );
      var H = a(218),
        M = a(219),
        Z = a(4),
        V = (function () {
          function e() {
            Object(H.a)(this, e), (this.feeds = []), (this.feed = "");
          }
          return (
            Object(M.a)(e, [
              {
                key: "setFeeds",
                value: function (e) {
                  this.feeds = e;
                },
              },
              {
                key: "setSelectedFeed",
                value: function (e) {
                  this.feed = e;
                },
              },
            ]),
            e
          );
        })(),
        Y = new (V = Object(Z.h)(V, {
          feeds: Z.m,
          feed: Z.m,
          setFeeds: Z.d,
          setSelectedFeed: Z.d,
        }))();
      c.a.locale(m.a),
        l.a.render(
          r.a.createElement(
            o.a,
            { basename: "/news" },
            r.a.createElement(G, { feedsStore: Y })
          ),
          document.getElementById("root")
        ),
        "serviceWorker" in navigator &&
          navigator.serviceWorker.ready.then(function (e) {
            e.unregister();
          });
    },
  },
  [[222, 1, 2]],
]);
//# sourceMappingURL=main.1af430b2.chunk.js.map
