(window["webpackJsonpreact-rss-tutorial-app"] =
  window["webpackJsonpreact-rss-tutorial-app"] || []).push([
  [0],
  {
    222: function (e, t, a) {
      e.exports = a(481);
    },
    227: function (e, t, a) {},
    229: function (e, t, a) {},
    376: function (e, t, a) {},
    398: function (e, t, a) {},
    417: function (e, t) {},
    419: function (e, t) {},
    452: function (e, t) {},
    454: function (e, t) {},
    481: function (e, t, a) {
      "use strict";
      a.r(t);
      var r = a(0),
        n = a.n(r),
        s = a(39),
        c = a.n(s),
        l = a(489),
        o = a(26),
        i = a(220),
        u = a.n(i),
        m = (a(227), a(32)),
        d = a(33),
        h = a.n(d),
        p = a(56),
        f = a(51),
        w = (a(229), a(78)),
        b = a(21),
        g = a.n(b),
        v = a(221),
        E = a(28),
        y = a.n(E),
        S = a(77),
        x = a.n(S),
        k = a(50),
        T = a.n(k),
        O = a(80),
        //Change default urls here
        j = [
          {
            name: "Null Byte",
            url: "https://null-byte.wonderhowto.com/rss.xml",
          },
          {
            name: "HackerNews",
            url: "https://feeds.feedburner.com/TheHackersNews",
          },
          { name: "ESET", url: "http://feeds.feedburner.com/eset/blog/" },
          { name: "Phoronix", url: "https://www.phoronix.com/rss.php" },
          { name: "AnandTech", url: "https://www.anandtech.com/rss/" },
          { name: "wccftech", url: "https://wccftech.com/feed/" },
          { name: "Tech Worm", url: "https://www.techworm.net/feed" },
          { name: "KrebSon", url: "\t'https://krebsonsecurity.com/feed/'" },
          {
            name: "Washington Examiner",
            url: "https://www.washingtonexaminer.com/tag/technology.rss",
          },
          { name: "The Wire Cutter", url: "https://thewirecutter.com/feed/" },
          {
            name: "The Inquirer",
            url: "https://www.theinquirer.net/feeds/rss",
          },
          { name: "RiskyBiz", url: "https://risky.biz/rss.xml" },
          {
            name: "CX Security",
            url: "https://cxsecurity.com/wlb/rss/exploit/",
          },
          {
            name: "Seclists",
            url: "http://seclists.org/rss/fulldisclosure.rss",
          },
          {
            name: "Security Weekly",
            url: "http://feeds.feedburner.com/securityweekly/",
          },
          { name: "Deep Dot Web", url: "https://www.deepdotweb.com/feed/" },
          {
            name: "Macrumors",
            url: "http://feeds.macrumors.com/MacRumors-All",
          },
          { name: "9to5Mac", url: "https://9to5mac.com/feed/" },
          {
            name: "neowin-main",
            url: "https://feeds.feedburner.com/neowin-main",
          },
          { name: "Securelist", url: "https://securelist.com/feed/" },
          { name: "XDA", url: "https://www.xda-developers.com/feed/" },
          { name: "Eff", url: "https://www.eff.org/rss/updates.xml" },
          { name: "ONMSFT", url: "https://www.onmsft.com/feed" },
          { name: "Fossbytes", url: "https://fossbytes.com/feed/" },
          {
            name: "Bleeping Computer",
            url: "https://www.bleepingcomputer.com/feed/",
          },
          { name: "Ghacks", url: "https://www.ghacks.net/feed/" },
          {
            name: "Naked Security",
            url: "https://nakedsecurity.sophos.com/feed/",
          },
          { name: "ZD Net", url: "http://www.zdnet.com/blog/security/rss.xml" },
          {
            name: "Security Affairs",
            url: "http://securityaffairs.co/wordpress/feed",
          },
          {
            name: "Dark Reading",
            url: "https://www.darkreading.com/rss_simple.asp",
          },
          {
            name: "Extreme Tech",
            url: "https://www.extremetech.com/computing/feed",
          },
          { name: "TWIT", url: "http://feeds.twit.tv/brickhouse_video_hd.xml" },
          {
            name: "Welivesecurity",
            url: "https://www.welivesecurity.com/feed/",
          },
          {
            name: "Tech Republic",
            url: "https://www.techrepublic.com/rssfeeds/articles/",
          },
          {
            name: "Tech Crunch",
            url: "http://feeds.feedburner.com/TechCrunch/",
          },
          {
            name: "Computer World",
            url: "http://www.computerworld.com/news/index.rss",
          },
          { name: "ExtremeTech", url: "https://www.extremetech.com/feed" },
          { name: "Tech Radar", url: "http://www.techradar.com/rss" },
          { name: "Read Write", url: "https://readwrite.com/feed/" },
          {
            name: "Guardian, Technology",
            url: "https://www.theguardian.com/us/technology/rss",
          },
          {
            name: "Linux Insider",
            url: "https://www.linuxinsider.com/perl/syndication/rssfull.pl",
          },
          {
            name: "LXER",
            url: "http://lxer.com/module/newswire/headlines.rss",
          },
          { name: "Coin Desk", url: "https://feeds.feedburner.com/CoinDesk" },
          { name: "Coin Telegraph", url: "https://cointelegraph.com/rss" },
          { name: "The Verge", url: "https://www.theverge.com/rss/index.xml" },
          {
            name: "The Register",
            url: "https://www.theregister.co.uk/headlines.atom",
          },
          { name: "Threat Post", url: "https://threatpost.com/feed/" },
          {
            name: "ARS Technica",
            url: "http://feeds.arstechnica.com/arstechnica/index/",
          },
          {
            name: "Reuters Technology",
            url: "http://feeds.reuters.com/reuters/technologyNews",
          },
          { name: "Guru 3D", url: "https://www.guru3d.com/news_rss" },
          {
            name: "Slash Dot",
            url: "http://rss.slashdot.org/Slashdot/slashdotMain",
          },
          {
            name: "Torrent Freak",
            url: "https://feeds.feedburner.com/Torrentfreak",
          },
        ],
        N = a(169),
        C = O.object({
          name: O.string().required("URL is required"),
          url: O.string()
            .required("URL is required")
            .matches(
              /(https?:\/\/)?([\w\-])+\.{1}([a-zA-Z]{2,63})([\/\w-]*)*\/?\??([^#\n\r]*)?#?([^\n\r]*)/,
              "Invalid URL"
            ),
        });
      var D = Object(w.a)(function (e) {
          var t = this,
            a = e.feedsStore,
            s = Object(r.useState)(!1),
            c = Object(f.a)(s, 2),
            l = c[0],
            o = c[1],
            i = Object(r.useState)(!1),
            u = Object(f.a)(i, 2),
            d = u[0],
            w =
              (u[1],
              (function () {
                var e = Object(p.a)(
                  h.a.mark(function e(t, r) {
                    var n, s, c;
                    return h.a.wrap(
                      function (e) {
                        for (;;)
                          switch ((e.prev = e.next)) {
                            case 0:
                              return (
                                (n = r.setSubmitting),
                                (s = r.setErrors),
                                (c = r.resetForm),
                                (e.prev = 1),
                                (e.next = 4),
                                C.validate(t)
                              );
                            case 4:
                              c({}),
                                a.feeds.push(t),
                                a.setFeeds(a.feeds),
                                localStorage.setItem(
                                  "techfeeds",
                                  JSON.stringify(a.feeds)
                                ),
                                (e.next = 14);
                              break;
                            case 10:
                              (e.prev = 10),
                                (e.t0 = e.catch(1)),
                                n(!1),
                                s({ submit: e.t0.message });
                            case 14:
                            case "end":
                              return e.stop();
                          }
                      },
                      e,
                      null,
                      [[1, 10]]
                    );
                  })
                );
                return function (t, a) {
                  return e.apply(this, arguments);
                };
              })()),
            b = function (e) {
              a.feeds.splice(e, 1),
                a.setFeeds(a.feeds),
                localStorage.setItem("techfeeds", JSON.stringify(a.feeds));
            };
          return (
            Object(r.useEffect)(
              function () {
                if (!l) {
                  var e = [];
                  try {
                    (e = JSON.parse(localStorage.getItem("techfeeds"))),
                      Array.isArray(e) ? a.setFeeds(e) : a.setFeeds(j);
                  } catch (t) {}
                  o(!0), console.log("Useeffect ran");
                }
              },
              [l]
            ),
            d
              ? n.a.createElement(m.a, {
                  to: "/feed?".concat(N.encode({ url: a.feed })),
                })
              : n.a.createElement(
                  "div",
                  { className: "home-page" },
                  n.a.createElement("h1", { className: "center" }, "RSS Feeds"),
                  n.a.createElement(
                    v.a,
                    {
                      validationSchema: C,
                      onSubmit: w,
                      initialValues: { name: "", url: "" },
                    },
                    function (e) {
                      var t = e.handleSubmit,
                        a = e.handleChange,
                        r = (e.handleBlur, e.values),
                        s = e.touched,
                        c = (e.isInvalid, e.errors);
                      return n.a.createElement(
                        "div",
                        null,
                        n.a.createElement("h5", null, "Add a RSS feed"),
                        n.a.createElement(
                          y.a,
                          { noValidate: !0, onSubmit: t },
                          n.a.createElement(
                            y.a.Row,
                            null,
                            n.a.createElement(
                              y.a.Group,
                              { as: x.a, md: "12", controlId: "name" },
                              n.a.createElement(y.a.Control, {
                                type: "text",
                                name: "name",
                                placeholder: "Name",
                                value: r.name || "",
                                onChange: a,
                                isInvalid: s.name && c.name,
                              }),
                              n.a.createElement(
                                y.a.Control.Feedback,
                                { type: "invalid" },
                                c.name
                              )
                            ),
                            n.a.createElement(
                              y.a.Group,
                              { as: x.a, md: "12", controlId: "url" },
                              n.a.createElement(y.a.Control, {
                                type: "text",
                                name: "url",
                                placeholder: "URL",
                                value: r.url || "",
                                onChange: a,
                                isInvalid: s.url && c.url,
                              }),
                              n.a.createElement(
                                y.a.Control.Feedback,
                                { type: "invalid" },
                                c.url
                              )
                            )
                          ),
                          n.a.createElement(T.a, { type: "submit" }, "Add")
                        )
                      );
                    }
                  ),
                  n.a.createElement("br", null),
                  n.a.createElement(
                    T.a,
                    {
                      variant: "primary",
                      onClick: function () {
                        localStorage.removeItem("techfeeds"), o(!1);
                      },
                    },
                    "Reset All"
                  ),
                  n.a.createElement("br", null),
                  n.a.createElement("br", null),
                  a.feeds.map(function (e, a) {
                    return n.a.createElement(
                      g.a,
                      { key: a },
                      n.a.createElement(
                        g.a.Title,
                        { className: "card-title" },
                        e.name
                      ),
                      n.a.createElement(
                        g.a.Subtitle,
                        { style: { paddingLeft: "20px" } },
                        e.url
                      ),
                      n.a.createElement(
                        g.a.Body,
                        null,
                        n.a.createElement(
                          T.a,
                          { variant: "primary", onClick: b.bind(t, a) },
                          "Delete"
                        )
                      )
                    );
                  })
                )
          );
        }),
        R = (a(376), a(216)),
        F = a(59),
        I = a.n(F),
        A = a(127),
        B = a.n(A);
      var W = Object(m.f)(function (e) {
          return (
            Object(R.a)(e),
            n.a.createElement(
              I.a,
              { bg: "primary", expand: "lg", variant: "dark" },
              n.a.createElement(
                I.a.Brand,
                null,
                n.a.createElement(
                  o.b,
                  {
                    style: { color: "white", textDecoration: "none" },
                    to: "/",
                  },
                  "Tech"
                )
              ),
              n.a.createElement(I.a.Toggle, {
                "aria-controls": "basic-navbar-nav",
              }),
              n.a.createElement(
                I.a.Collapse,
                { id: "basic-navbar-nav" },
                n.a.createElement(
                  B.a,
                  { className: "mr-auto" },
                  n.a.createElement(
                    B.a.Link,
                    {
                      href: "https://weboas.is/",
                      style: { color: "white", textDecoration: "none" },
                    },
                    "Home"
                  ),
                  n.a.createElement(
                    o.b,
                    {
                      style: { color: "white", textDecoration: "none" },
                      className: "nav-item nav-link active",
                      to: "/settings",
                    },
                    "Settings"
                  )
                )
              )
            )
          );
        }),
        q = a(490),
        L = (a(398), a(399)),
        J = a(445),
        G = a(446),
        M = (new (a(447))(), a(470));
      var U = Object(m.f)(
        Object(w.a)(function (e) {
          var t = this,
            a = e.feedsStore,
            s = Object(r.useState)(!1),
            c = Object(f.a)(s, 2),
            l = c[0],
            o = c[1],
            i = Object(r.useState)([]),
            u = Object(f.a)(i, 2),
            m = u[0],
            d = u[1],
            w = [],
            b = (function () {
              var e = Object(p.a)(
                h.a.mark(function e(t) {
                  return h.a.wrap(function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            L.load(
                              "https://req.prototypr.io/" + t.url,
                              function (e, a) {
                                if (e) console.log("error" + t);
                                else {
                                  a.items.map(function (e) {
                                    return (e.sourceName = a.title);
                                  });
                                  var r = M.uniqBy(a.items, "title");
                                  w.push(M.uniqBy(a.items, "title")),
                                    (r = []),
                                    d(w.flat()),
                                    console.log(r);
                                }
                              }
                            )
                          );
                        case 2:
                        case "end":
                          return e.stop();
                      }
                  }, e);
                })
              );
              return function (t) {
                return e.apply(this, arguments);
              };
            })();
          Object(r.useEffect)(
            function () {
              if (!l) {
                var e = [];
                try {
                  (e = JSON.parse(localStorage.getItem("techfeeds"))),
                    Array.isArray(e) ? a.setFeeds(e) : a.setFeeds(j);
                } catch (t) {
                  console.log("error" + t);
                }
                a.feeds.map(
                  (function () {
                    var e = Object(p.a)(
                      h.a.mark(function e(t) {
                        return h.a.wrap(function (e) {
                          for (;;)
                            switch ((e.prev = e.next)) {
                              case 0:
                                return (e.next = 2), b(t);
                              case 2:
                                (w = []), console.log("I am updating");
                              case 4:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                      })
                    );
                    return function (t) {
                      return e.apply(this, arguments);
                    };
                  })()
                );
              }
              o(!0);
            },
            [l]
          );
          var v = function (e) {
            window.open(e);
          };
          return 0 === m.length
            ? n.a.createElement(
                "div",
                { className: "feed-page" },
                n.a.createElement("h2", null, " Loading! "),
                " "
              )
            : n.a.createElement(
                "div",
                { className: "feed-page" },
                " ",
                m
                  .sort(function (e, t) {
                    var a = new Date(e.pubDate).getTime();
                    return new Date(t.pubDate).getTime() - a;
                  })
                  .splice(0, 250)
                  .map(function (e, a) {
                    if (void 0 != e.pubDate)
                      return n.a.createElement(
                        g.a,
                        { key: a },
                        n.a.createElement(
                          g.a.Header,
                          { className: "card-title" },
                          " ",
                          e.title,
                          " "
                        ),
                        n.a.createElement(
                          g.a.Body,
                          null,
                          n.a.createElement(
                            g.a.Text,
                            null,
                            " ",
                            G.decode(
                              J(e.description).substring(0, 150) + "..."
                            ),
                            " "
                          ),
                          " ",
                          n.a.createElement(
                            g.a.Text,
                            { className: "time-ago" },
                            n.a.createElement(
                              "span",
                              null,
                              n.a.createElement(q.a, {
                                date: new Date(e.pubDate),
                              }),
                              " ",
                              n.a.createElement(
                                "span",
                                null,
                                " ",
                                "  from ".concat(e.sourceName),
                                " "
                              ),
                              " "
                            ),
                            " "
                          ),
                          " ",
                          " ",
                          n.a.createElement(
                            T.a,
                            { variant: "primary", onClick: v.bind(t, e.link) },
                            "Open",
                            " "
                          ),
                          " "
                        ),
                        " "
                      );
                  }),
                " "
              );
        })
      );
      var z = function (e) {
        var t = e.feedsStore;
        return n.a.createElement(
          "div",
          { className: "App" },
          n.a.createElement(W, null),
          n.a.createElement(m.b, {
            path: "/",
            exact: !0,
            component: function (e) {
              return n.a.createElement(
                U,
                Object.assign({}, e, { feedsStore: t })
              );
            },
          }),
          n.a.createElement(m.b, {
            path: "/settings",
            exact: !0,
            component: function (e) {
              return n.a.createElement(
                D,
                Object.assign({}, e, { feedsStore: t })
              );
            },
          })
        );
      };
      Boolean(
        "localhost" === window.location.hostname ||
          "[::1]" === window.location.hostname ||
          window.location.hostname.match(
            /^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/
          )
      );
      var H = a(218),
        _ = a(219),
        V = a(4),
        X = (function () {
          function e() {
            Object(H.a)(this, e), (this.feeds = []), (this.feed = "");
          }
          return (
            Object(_.a)(e, [
              {
                key: "setFeeds",
                value: function (e) {
                  this.feeds = e;
                },
              },
              {
                key: "setSelectedFeed",
                value: function (e) {
                  this.feed = e;
                },
              },
            ]),
            e
          );
        })(),
        P = new (X = Object(V.h)(X, {
          feeds: V.m,
          feed: V.m,
          setFeeds: V.d,
          setSelectedFeed: V.d,
        }))();
      l.a.locale(u.a),
        c.a.render(
          n.a.createElement(
            o.a,
            { basename: "/tech" },
            n.a.createElement(z, { feedsStore: P })
          ),
          document.getElementById("root")
        ),
        "serviceWorker" in navigator &&
          navigator.serviceWorker.ready.then(function (e) {
            e.unregister();
          });
    },
  },
  [[222, 1, 2]],
]);
//# sourceMappingURL=main.c7919d01.chunk.js.map
