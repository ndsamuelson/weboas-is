import React, { useEffect } from "react";
import { observer } from "mobx-react-lite";
import "./darkModeToggler.css";
const DarkModeToggler = observer(({ userStore }) => {
  const darkModeSettings = (e) => {
    userStore.setDarkMode(e);
    localStorage.setItem("ipfs-darkmode", JSON.stringify(e));
  };
  useEffect(() => {
    try {
      var color = JSON.parse(localStorage.getItem("ipfs-darkmode"));
      if (color === false || color === true) {
        userStore.setDarkMode(color);
      }
    } catch (err) {
      console.log("error" + err);
    }
  }, [userStore]);
  return (
    <div>
      <nav
        className={
          userStore.darkMode !== true
            ? "navbar  navbar-expand-lg row navbar-light bg-light"
            : "navbar navbar-expand-lg row navbar-dark bg-secondary"
        }
      >
        <a className="navbar-brand" href="/#">
          Image Host
        </a>
        <div className="" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item active">
              <a className="nav-link" href="https://weboas.is/">
                Home <span className="sr-only">(current)</span>
              </a>
            </li>
            <li className="nav-item active">
              <button
                type="button"
                className={
                  userStore.darkMode !== true
                    ? "btn toggle-switch btn-primary"
                    : "btn toggle-switch btn-info"
                }
                onClick={() => darkModeSettings(!userStore.darkMode)}
              >
                Toggle Dark Mode
              </button>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  );
});

export default DarkModeToggler;
