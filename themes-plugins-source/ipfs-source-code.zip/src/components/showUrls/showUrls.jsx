import React, { useState, useEffect } from "react";
import { observer } from "mobx-react-lite";
import parseUrl from "parse-url";
import "./showUrls.css";

const ShowUrls = observer(({ userStore }) => {
  const [urls, setUrls] = useState([]);

  useEffect(() => {
    fetch(
      "https://raw.githubusercontent.com/ipfs/public-gateway-checker/master/gateways.json"
    )
      .then((response) => response.json())
      .then((parsedata) => {
        setUrls(parsedata.slice(0, 20));
      })
      .catch((error) => {
        // handle your errors here
        console.error(error);
      });
  }, []);
  const handleCopy = (url, i) => {
    var dummy = document.createElement("textarea");
    document.body.appendChild(dummy);
    dummy.value = url.slice(0, -5) + userStore.storageValue;
    dummy.select();
    document.execCommand("copy");
    document.body.removeChild(dummy);
    let clickedElement = document.getElementsByClassName("copy-button")[i];
    clickedElement.innerHTML = "copied";
    setTimeout(function () {
      clickedElement.innerHTML = "copy";
    }, 500);
  };

  return (
    <div>
      <p className="h4">Image URLs</p>
      {userStore.errorMessage !== "" ? (
        <p className="alert alert-danger">{userStore.errorMessage}</p>
      ) : (
        ""
      )}
      {userStore.isLoading ? (
        "Please wait.."
      ) : userStore.storageValue === "" ? (
        ""
      ) : (
        <ul>
          {urls.map((url, i) => {
            return (
              <li key={i}>
                <p className="h5">
                  <a
                    className={
                      userStore.darkMode !== true
                        ? "badge badge-primary"
                        : "badge badge-info"
                    }
                    href={url.slice(0, -5) + userStore.storageValue}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {parseUrl(url).resource}
                  </a>
                  <button
                    className="copy-button btn badge badge-warning"
                    onClick={() => {
                      handleCopy(url, i);
                    }}
                  >
                    copy
                  </button>
                </p>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
});
export default ShowUrls;
