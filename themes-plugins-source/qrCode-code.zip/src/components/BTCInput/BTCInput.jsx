import { useForm } from "react-hook-form";
import { observer } from "mobx-react-lite"; // Or "mobx-react".

const BTCInput = observer(({ userStore }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (data) =>
    userStore.setQrData(
      `bitcoin:${data.account}${data.amount ? "?amount=" + data.amount : ""}${
        data.item_name ? "&label=" + data.item_name : ""
      }${data.message ? "&message=" + data.message : ""}`
    );
  return (
    <div>
      <h4 className="mt-3">Bitcoin</h4>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="account"
        >
          Account
        </label>
        <input {...register("account", { required: true })} />
        {errors.account && <span>This field is required</span>}
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="amount"
        >
          Amount
        </label>
        <input {...register("amount")} />
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="password"
        >
          Item Name
        </label>
        <input {...register("item_name")} />
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="password"
        >
          Message
        </label>
        <input {...register("message")} />
        <input className="btn-primary" type="submit" value="submit" />
      </form>
    </div>
  );
});
export default BTCInput;
