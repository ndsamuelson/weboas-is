import { useForm } from "react-hook-form";
import { observer } from "mobx-react-lite"; // Or "mobx-react".

const ETHInput = observer(({ userStore }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (data) => userStore.setQrData(`ethereum:${data.account}`);
  return (
    <div>
      <h4 className="mt-3">Ethereum</h4>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="account"
        >
          Account
        </label>
        <input {...register("account", { required: true })} />
        {errors.account && <span>This field is required</span>}
        <input className="btn-primary" type="submit" value="submit" />
      </form>
    </div>
  );
});
export default ETHInput;
