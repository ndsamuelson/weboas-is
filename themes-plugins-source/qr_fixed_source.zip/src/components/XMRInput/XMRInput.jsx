import { useForm } from "react-hook-form";
import { observer } from "mobx-react-lite"; // Or "mobx-react".

const XMRInput = observer(({ userStore }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (data) =>
    userStore.setQrData(
      `monero:${data.address}${
        data.tx_amount ? "?tx_amount=" + data.tx_amount : ""
      }${data.tx_payment_id ? "&tx_payment_id=" + data.tx_payment_id : ""}${
        data.tx_description ? "&tx_description=" + data.tx_description : ""
      }${data.recipient_name ? "&recipient_name=" + data.recipient_name : ""}`
    );
  return (
    <div>
      <h4 className="mt-3">Monero</h4>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="account"
        >
          Address
        </label>
        <input {...register("address", { required: true })} />
        {errors.address && <span>This field is required</span>}
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="amount"
        >
          Amount
        </label>
        <input {...register("tx_amount")} />
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="password"
        >
          Payment ID
        </label>
        <input {...register("tx_payment_id")} />
        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="password"
        >
          Description
        </label>
        <input {...register("tx_description")} />

        <label
          className={userStore.darkMode !== true ? "text-dark" : ""}
          htmlFor="password"
        >
          Recepient Name
        </label>
        <input {...register("recipient_name")} />
        <input className="btn-primary" type="submit" value="submit" />
      </form>
    </div>
  );
});
export default XMRInput;
